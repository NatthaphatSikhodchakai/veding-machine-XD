#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import os, sys

ALLOWED_DENOMS: List[int] = [1, 2, 5, 10, 20, 50, 100, 500, 1000]
ADMIN_PASSWORD_DEFAULT = "1234"

GOODS_FILE = "Goods.txt"
WALLET_FILE = "Wallet.txt"

# ----------------------- No-Enter key helpers -----------------------
def _getch() -> str:
    """Read a single key without Enter (Windows/Unix terminals)."""
    try:
        import msvcrt  # type: ignore
        ch = msvcrt.getch()
        if ch in (b"\x00", b"\xe0"):
            # swallow special-key prefix
            msvcrt.getch()
            return ""
        return ch.decode("utf-8", errors="ignore")
    except Exception:
        import tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return ch

def get_key(valid: set[str], prompt: str) -> str:
    """Wait for one valid key; echo it and return lowercase."""
    print(prompt, end="", flush=True)
    while True:
        k = _getch().lower()
        if k in valid:
            print(k)
            return k

# ----------------------- Models -----------------------
@dataclass
class Product:
    code: str
    name: str
    price: int
    qty: int
    def is_available(self) -> bool:
        return self.qty > 0
    def decrease(self, amount: int = 1) -> None:
        self.qty = max(0, self.qty - amount)

class Wallet:
    def __init__(self) -> None:
        self.cash: Dict[int, int] = {d: 0 for d in ALLOWED_DENOMS}
    def load_from_file(self, path: str = WALLET_FILE) -> None:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Wallet file not found: {path}")
        tmp: Dict[int, int] = {d: 0 for d in ALLOWED_DENOMS}
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = [p.strip() for p in line.split(",")]
                if len(parts) != 2:
                    continue
                try:
                    denom = int(parts[0]); cnt = int(parts[1])
                except ValueError:
                    continue
                if denom in tmp and cnt >= 0:
                    tmp[denom] = cnt
        self.cash = tmp
    def save_to_file(self, path: str = WALLET_FILE) -> None:
        with open(path, "w", encoding="utf-8") as f:
            for d in ALLOWED_DENOMS:
                f.write(f"{d},{self.cash.get(d,0)}\n")
    def deposit(self, cash_in: Dict[int, int]) -> None:
        for d, c in cash_in.items():
            if d in ALLOWED_DENOMS and c > 0:
                self.cash[d] = self.cash.get(d, 0) + c
    def _simulate_change(self, change_amount: int) -> Optional[Dict[int, int]]:
        if change_amount < 0:
            return None
        if change_amount == 0:
            return {}
        remaining = change_amount
        denoms = sorted(ALLOWED_DENOMS, reverse=True)
        take: Dict[int, int] = {}
        stock = self.cash.copy()
        for d in denoms:
            if remaining <= 0:
                break
            if d > remaining:
                continue
            max_need = remaining // d
            can_take = min(max_need, stock.get(d, 0))
            if can_take > 0:
                take[d] = can_take
                remaining -= d * can_take
                stock[d] -= can_take
        if remaining == 0:
            return take
        # fallback
        remaining = change_amount
        take = {}
        for d in sorted(ALLOWED_DENOMS):
            if remaining <= 0:
                break
            max_need = remaining // d
            can_take = min(max_need, self.cash.get(d, 0) - take.get(d, 0))
            if can_take > 0:
                take[d] = take.get(d, 0) + can_take
                remaining -= d * can_take
        return take if remaining == 0 else None
    def can_make_change(self, change_amount: int) -> bool:
        return self._simulate_change(change_amount) is not None
    def make_change(self, change_amount: int) -> Optional[Dict[int, int]]:
        take = self._simulate_change(change_amount)
        if take is None:
            return None
        for d, c in take.items():
            self.cash[d] -= c
        return take

# ----------------------- Core -----------------------
class VendingMachine:
    def __init__(self, admin_password: str = ADMIN_PASSWORD_DEFAULT) -> None:
        self.products: Dict[str, Product] = {}
        self.wallet = Wallet()
        self.admin_password = admin_password
    def load_goods(self, path: str = GOODS_FILE) -> None:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Goods file not found: {path}")
        tmp: Dict[str, Product] = {}
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = [p.strip() for p in line.split(",")]
                if len(parts) != 4:
                    continue
                code, name, price_str, qty_str = parts
                try:
                    price = int(price_str); qty = int(qty_str)
                except ValueError:
                    continue
                if code and (10 <= price <= 100) and qty >= 0:
                    tmp[code] = Product(code, name, price, qty)
        self.products = tmp
    def save_goods(self, path: str = GOODS_FILE) -> None:
        with open(path, "w", encoding="utf-8") as f:
            for code in sorted(self.products.keys(), key=lambda x: (len(x), x)):
                p = self.products[code]
                f.write(f"{p.code},{p.name},{p.price},{p.qty}\n")
    def load_wallet(self, path: str = WALLET_FILE) -> None:
        self.wallet.load_from_file(path)
    def save_wallet(self, path: str = WALLET_FILE) -> None:
        self.wallet.save_to_file(path)

    # --- Buy Flow ---
    def list_goods(self) -> List[Product]:
        return [self.products[k] for k in sorted(self.products.keys(), key=lambda x: (len(x), x))]
    def select_item(self, code: str) -> Optional[Product]:
        p = self.products.get(code)
        return p if (p and p.is_available()) else None
    def process_payment(self, price: int, cash_in: Dict[int, int]) -> Tuple[bool, Optional[Dict[int, int]], str]:
        total_in = 0
        for d, c in cash_in.items():
            if d not in ALLOWED_DENOMS or c < 0:
                return False, None, "other"
            total_in += d * c
        if total_in < price:
            return False, None, "insufficient"
        change = total_in - price
        if not self.wallet.can_make_change(change):
            return False, None, "no_change"
        self.wallet.deposit(cash_in)
        change_pack = self.wallet.make_change(change) or {}
        return True, change_pack, ""

    def deliver(self, item: Product, change: Dict[int, int]) -> None:
        item.decrease(1)

    def refund(self, cash_in: Dict[int, int]) -> Dict[int, int]:
        return cash_in

    # --- Maintenance ---
    def login_admin(self, password: str) -> bool:
        return password == self.admin_password
    def restock_goods(self, items: Dict[str, int]) -> None:
        for code, add in items.items():
            if code in self.products and add != 0:
                self.products[code].qty = max(0, self.products[code].qty + add)
    def restock_wallet(self, cash_pack: Dict[int, int]) -> None:
        self.wallet.deposit(cash_pack)

    # --- Shutdown ---
    def shutdown(self) -> None:
        self.save_goods()
        self.save_wallet()
        print("Goodbye!")

# ----------------------- CLI Helpers -----------------------
def read_line(prompt: str) -> str:
    try:
        return input(prompt)
    except EOFError:
        return ""

def read_int(prompt: str) -> int:
    while True:
        s = read_line(prompt).strip()
        if s.lstrip("-").isdigit():
            return int(s)
        print("Please enter a valid integer.")

def summarize_cash_pack(pack: Dict[int, int]) -> str:
    items = [f"{d}x{c}" for d, c in sorted(pack.items()) if c > 0]
    total = sum(d * c for d, c in pack.items())
    return f"[{', '.join(items) if items else '-'}] = {total}"

# ----------------------- CLI Screens -----------------------
def cli_buy(vm: VendingMachine) -> None:
    while True:
        print("\n--- BUY GOODS ---")
        goods = vm.list_goods()
        for p in goods:
            status = f"{p.qty} left" if p.qty > 0 else "SOLD OUT"
            print(f"[{p.code}] {p.name:12s} {p.price:>3d}  ({status})")
        print("(e) Finish purchase and return to Main Menu")

        valid = set([p.code for p in goods if p.qty > 0]) | {"e"}
        code = get_key(valid, "Select an item code or 'e': ")
        if code == "e":
            break

        item = vm.select_item(code)
        if not item:
            print("Item not available (invalid code or sold out).")
            continue

        print(f"\nSelected: {item.name}")
        print(f"Price   : {item.price}")
        print("Insert cash (denoms: 1,2,5,10,20,50,100,500,1000). Type 'c' to cancel.")

        cash_in: Dict[int, int] = {d: 0 for d in ALLOWED_DENOMS}
        total = 0
        while True:
            remaining = max(0, item.price - total)
            print(f"[HUD] Total-in: {total}  | Remaining: {remaining}  | Inserted: {summarize_cash_pack(cash_in)}")
            s = read_line("Insert or 'c' to cancel: ").strip().lower()

            if s == "c":
                refund = vm.refund(cash_in)
                if sum(k*v for k, v in refund.items()) > 0:
                    print("Refunded:", refund)
                else:
                    print("Canceled. No money inserted.")
                break

            try:
                denom = int(s)
                if denom not in ALLOWED_DENOMS:
                    print("Invalid denomination. Allowed:", ALLOWED_DENOMS)
                    continue
                cash_in[denom] += 1
                total += denom
            except ValueError:
                print("Please enter a denomination (e.g., 10, 20, 50) or 'c' to cancel.")
                continue

            if total >= item.price:
                ok, change_pack, reason = vm.process_payment(item.price, cash_in)
                if ok:
                    vm.deliver(item, change_pack or {})
                    change_amount = sum(d*c for d, c in (change_pack or {}).items())
                    print("\n=== PAYMENT RESULT ===")
                    print(f"Total-in: {total} | Price: {item.price} | Change: {change_amount}")
                    if change_pack:
                        print("Change breakdown:", change_pack)
                    else:
                        print("Exact payment, no change.")
                else:
                    if reason == "no_change":
                        print("Cannot provide change. Refunding your cash...")
                    elif reason == "insufficient":
                        print("Not enough money. Refunding...")
                    else:
                        print("Transaction failed. Refunding...")
                    refund = vm.refund(cash_in)
                    print("Refunded:", refund)
                break

def cli_maintenance(vm: VendingMachine) -> None:
    pwd = read_line("Enter admin password: ").strip()
    if not vm.login_admin(pwd):
        print("Wrong password.")
        return
    while True:
        print("\n--- MAINTENANCE ---")
        print("[g] Load Goods.txt")
        print("[w] Load Wallet.txt")
        print("[v] View Goods")
        print("[k] View Wallet")
        print("[r] Restock Goods (multi; blank/e/c to exit)")
        print("[t] Topup Wallet (multi; blank to finish)")
        print("[c] Exit Maintenance")
        k = read_line("Select: ").strip().lower()

        if k == "g":
            try:
                vm.load_goods(GOODS_FILE)
                print("Loaded goods from file.")
            except Exception as e:
                print("Error:", e)

        elif k == "w":
            try:
                vm.load_wallet(WALLET_FILE)
                print("Loaded wallet from file.")
            except Exception as e:
                print("Error:", e)

        elif k == "v":
            print("\n-- Current Goods --")
            for p in vm.list_goods():
                print(f"{p.code:>2}  {p.name:<12}  {p.price:>3}  qty={p.qty}")

        elif k == "k":
            print("\n-- Current Wallet --")
            print(vm.wallet.cash)

        elif k == "r":
            print("Enter restock items. Leave code blank or type 'e'/'c' to finish.")
            while True:
                code = read_line("Product code: ").strip()
                if code == "" or code.lower() in ("e", "c"):
                    print("Exit restock.")
                    break
                try:
                    add = int(read_line("Quantity to add (can be negative to reduce): ").strip())
                except ValueError:
                    print("Please enter integer quantity.")
                    continue
                vm.restock_goods({code: add})
                print(f"Restocked {code}: {add}")

        elif k == "t":
            print("Enter topup as 'denom count' per line. Blank to finish.")
            pack: Dict[int, int] = {}
            while True:
                line = read_line(">> ").strip()
                if not line:
                    break
                parts = line.split()
                if len(parts) != 2:
                    print("Format: <denom> <count>")
                    continue
                try:
                    d = int(parts[0]); c = int(parts[1])
                except ValueError:
                    print("Please enter numbers.")
                    continue
                if d not in ALLOWED_DENOMS:
                    print(f"Invalid denom. Allowed: {ALLOWED_DENOMS}")
                    continue
                pack[d] = pack.get(d, 0) + c
            vm.restock_wallet(pack)
            print("Wallet topped up:", pack)

        elif k == "c":
            break
        else:
            print("Unknown command.")

def cli_shutdown(vm: VendingMachine) -> bool:
    pwd = read_line("Enter admin password: ").strip()
    if not vm.login_admin(pwd):
        print("Wrong password.")
        return False
    vm.shutdown()
    return True

def main():
    if not os.path.exists(GOODS_FILE):
        with open(GOODS_FILE, "w", encoding="utf-8") as f:
            f.write("1,Coke,20,5\n2,Water,10,8\n3,Snack,15,6\n4,Tea,25,4\n")
    if not os.path.exists(WALLET_FILE):
        with open(WALLET_FILE, "w", encoding="utf-8") as f:
            f.write("1,20\n2,20\n5,20\n10,20\n20,10\n50,10\n100,10\n500,5\n1000,2\n")

    vm = VendingMachine()
    try:
        vm.load_goods(GOODS_FILE)
        vm.load_wallet(WALLET_FILE)
    except Exception as e:
        print("Warning while loading files:", e)

    while True:
        print("\n==== VENDING MACHINE ====")
        print("[b] Buy")
        print("[m] Maintenance")
        print("[s] Shutdown")
        choice = get_key({'b','m','s'}, "Select (b/m/s): ")
        if choice == "b":
            cli_buy(vm)
        elif choice == "m":
            cli_maintenance(vm)
        elif choice == "s":
            if cli_shutdown(vm):
                break

if __name__ == "__main__":
    main()
