# -*- coding: utf-8 -*-
"""
Created on Fri Sep 12 19:52:19 2025

@author: FDT-CDTI
"""
import FileAndMem_class as FT

class Change:
    def __init__(self,change=None):
        self.change = change
        
    def ChangeMoney(self):
        Money = [1000,500,100,50,20,10,5,2,1]
        x = FT.walletToMem()[::-1]
        Mstr = ''
        Sumcg = 0
        chN = []
        for i , Value in enumerate(Money):
            if x[i].qty < self.change // Value:
                Mstr += f'{i+1} {x[i].name:4} {x[i].value:4} {0}\n'
                chN.append(0)
            else:
                Mstr += f'{i+1} {x[i].name:4} {x[i].value:4} {self.change // Value}\n'
                Sumcg += self.change // Value
                chN.append(self.change // Value)
                self.change %= Value
        return Sumcg, Mstr, chN
    
if __name__ == "__main__":
    Money = Change(10)
    print(Money.ChangeMoney()[1])
    
    
    