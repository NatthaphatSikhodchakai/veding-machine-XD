# -*- coding: utf-8 -*-
"""
Created on Tue Aug 29 14:36:26 2023

@author: kmutnb
"""

class Moneyset:
    def __init__(self,mID="",name="",value=0,qty=0):
        """ Constructor Method to create Moneyset instance """
        self.ID = mID
        self.name = name
        self.value = value
        self.qty = qty

    def __str__(self):
        return f'{self.ID:3} {self.name:20} {self.value:4d} {self.qty:4d}'

    def showTotalValue(self):
        """ show value*qty Method """
        return (self.value*self.qty)

class Goodset:
    def __init__(self,code="",name="",unitp=0,qty=0):
        """ Constructor Method to create Goodset instance """
        self.code = code
        self.name = name
        self.unitp = unitp
        self.qty = qty        

    def __str__(self):
        return f'{self.code:3} {self.name:20} {self.unitp:4d} {self.qty:4d}'
 
    def showGoodsValue(self):
        """ show Detail of Goodset Method """
        return (self.unitp * self.qty)


#สิ่งที่แก้เพิ่ม #สิ่งที่แก้เพิ่ม#สิ่งที่แก้เพิ่ม#สิ่งที่แก้เพิ่ม#สิ่งที่แก้เพิ่ม#สิ่งที่แก้เพิ่ม
def goodsToMem():  
    """ Read goods.txt file to goodsMem """
    fin = open('Goods.txt', 'r')

    # ทำ index 0 เป็น dummy (กันรายการที่ไม่ตั้งใจ เช่น Goods-S20)
    gMem = [ Goodset('0', '--reserved--', 0, 0) ]

    with fin:
        for gRecord in fin:
            gNo, gName, gPrice, gQty = gRecord.split()
            # ข้ามรายการที่รหัสเป็น 0 (ไม่ให้เข้าตู้ขาย)
            if int(gNo) == 0:
                continue
            gMem.append( Goodset(gNo, gName, int(gPrice), int(gQty)) )

    return gMem
#-------------------------------------------------------------------------

def showAllGoogsMem(gMem):
    """ Show All GoogsMem """
    sumA = 0    
    for oneGMem in gMem:
        totAmt = oneGMem.unitp * oneGMem.qty
        sumA += totAmt
        #print(f'{oneGMem.code:2} {oneGMem.name:20} {oneGMem.unitp:4} {oneGMem.qty:4}')
    return sumA

def showAllGoogsMem2(gMem):
    """ Show All GoogsMem """
    sumA = 0 
    for oneGMem in gMem:
        sumA += oneGMem.showGoodsValue()    
    return sumA

def showAllGoogsMem3(gMem):
    """ Show All GoogsMem """
    sumA = 0
    lenGMem = len(gMem)
    for i in range (1,lenGMem):
        sumA += gMem[i].showGoodsValue()    
    return sumA

def walletToMem():
    """ Read wallet.txt file to walletMem """
    fin = open('Wallet.txt', 'r')

    wlMem = []
    with fin:
        for wlRecord in fin:
            wID, wName, wValue, wQty = wlRecord.split()
            wlMem.append( Moneyset(wID,wName,int(wValue),int(wQty)) )
            
    return wlMem

def walletToInitCashMem():
    """ Read wallet.txt file to Cash Mem """
    fin = open('Wallet.txt', 'r')

    cashMem = []
    with fin:
        for chRec in fin:
            chID, chName, chValue, chQty = chRec.split()
            chQty = '0'
            cashMem.append( Moneyset(chID,chName,int(chValue),int(chQty)) )
    return cashMem

def showAllWalletMem(wlMem):
    """ Show All walletMem """
    sumA = 0
    for oneWLMem in wlMem:
        totAmt = oneWLMem.mValue * oneWLMem.qty
        sumA += totAmt
        print(f'{oneWLMem.mID:2} {oneWLMem.mName:20} {oneWLMem.mValue:4} {oneWLMem.qty:4}')
    return sumA

def inputAllWalletMemQty(wlMem):
    """ Enter All walletMem Qty """
    i = 0
    for oldOneMem in wlMem:
        newQty = input(f'{oldOneMem.ID},{oldOneMem.name},{oldOneMem.value},\nQty = {oldOneMem.qty} <none> = ')
        if (newQty == ''):
            newQty = oldOneMem.qty
        else:
            newQty = int(newQty)
            
        wlMem[i].qty = newQty
        i += 1

    return wlMem

def inputAllGoodsMemQty(gMem):
    """ Enter All Goods Qty """
    i = 0
    for oldOneMem in gMem:
        newQty = input(f'{oldOneMem.code},{oldOneMem.name},{oldOneMem.unitp},\nQty = {oldOneMem.qty} <none> = ')
        if (newQty == ''):
            newQty = oldOneMem.qty
        else:
            newQty = int(newQty)
            
        gMem[i].qty = newQty
        i += 1

    return gMem

def buyGoodsItem(gId,gMem):
    """ gId is integer"""
    gbuy = gMem[gId] 
    return gbuy
    
if __name__ == '__main__':
    goodsMem = goodsToMem()
    lengMem = len(goodsMem)
    for i in range (1,lengMem):
        print(goodsMem[i])
        
    sumA  = showAllGoogsMem(goodsMem)
    sumA2 = showAllGoogsMem2(goodsMem)
    sumA3 = showAllGoogsMem3(goodsMem)
    
    print(f'Sum All  is {sumA:10}')
    print(f'Sum All2 is {sumA2:10}')
    print(f'Sum All3 is {sumA3:10}')
    
    ans = input('Press Enter')