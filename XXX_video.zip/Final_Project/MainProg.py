# -*- coding: utf-8 -*-
"""
Created on Tue Aug 29 14:36:26 2023

@author: kmutnb
"""
#import MenuFn4Mac as MFn
import MenuFn as MFn
import FileAndMem_class as FMC
import Change_Money as CM
import Update_G_W as UP
import Maintenance as MT

# import os
#import msvcrt

if __name__ == '__main__':

    iMain = MFn.getMainMenu()
    while (iMain != 's'):
        if iMain == 'b':
            goodsMem = FMC.goodsToMem()
            iBuy = MFn.getBuyGoodsMenu(goodsMem)
            WalletMem = FMC.walletToMem()
            while (iBuy != 'e'):
                if (iBuy != 'e'):
                    gBuy = FMC.buyGoodsItem(int (iBuy),goodsMem)
                    #สิ่งที่เพิ่มมา
                    if gBuy.qty <= 0:
                        MFn.raw_input(1, '\nOut of stock🤯\n...(please Press Any key)...')
                        continue
                    #----------------------
                    ch, cashIn = MFn.getCashInMenu(gBuy)
                    totalMoney = MFn.showAllValueMoney(cashIn)
                    print(f'total money = {totalMoney}💰')
                    for i in range (len(cashIn)):
                        # if cashIn[i].qty:
                            print(cashIn[i])
                    change = totalMoney - gBuy.unitp
                    C = CM.Change(change)
                    Csum, Clist, chN = C.ChangeMoney()
                    print('---------------')
                    print('Cash in, we done.')
                    print('------🟢------')
                    if ch == 'c':
                        print(f"Change Money🎶 = {totalMoney}💰")
                        for i in range (len(cashIn)):
                        # if cashIn[i].qty:
                            print(cashIn[i])
                    elif Csum == 0 and change != 0 :
                        print('No coins, only bills😅')
                        print(f"Change Money🎶 = {totalMoney}💰")
                        for i in range (len(cashIn)):
                        # if cashIn[i].qty:
                            print(cashIn[i])
                    else:
                        print(f"Change Money🎶 = {Csum}💸")
                        print(Clist)
                        Up_G = UP.Update(goodsMem)
                        Up_G.LodSinkar(str(iBuy))
                        Up_G.Up_Goods()
                        Up_Money = UP.Update(WalletMem)
                        Up_Money.PurmTung(cashIn)
                        Up_Money.Up_Wallet()
                        
                        Lod_Money = UP.Update(WalletMem)
                        Lod_Money.LodTung(chN[::-1])
                        Lod_Money.Up_Wallet()
                    
                    MFn.raw_input(1,'\nBuy Goods Menu Select \nMuch love for grabbing this, fam🫶 \n...(please Press Any key)...')
                    
                else:
                    MFn.raw_input(1,"\nEnd Buys Menu \nBig ups for snaggin' one😎🤌 \n...(please Press Any key)...")
                    
                
                iBuy = MFn.getBuyGoodsMenu(goodsMem)            

        elif iMain == 'm':
            print("Enter your password🔒")
            PWD = '12345'
            getPWD = MFn.getPWD(5,"*")
            while PWD != getPWD:
                getPWD = MFn.getPWD(5,"*")
            
            x = input("\nGoods📦(g)| Or Wallet🪙(w)| Or Close⭕(c) \n<g,w,c> \n= ")
            MFn.clearScreen()
            if x == 'g':
                Up_G = MT.Mainten()
                Up_G.inputAllGoodsMemQty()
                Up_G.Up_Goods()
                
            elif x == 'w':    
                Up_W = MT.Mainten()
                Up_W.inputAllWalletMemQty()
                Up_W.Up_Wallet()
                
            elif x == 'c':
                MFn.raw_input(1,'⚠ Maintenance function⚠\n...(please Press Any key to exit)...')   
        elif iMain == 's':
            PWD = '12345'
            getPWD = MFn.getPWD(5,"*")
            while PWD != getPWD:
                getPWD = MFn.getPWD(5,"*")
                
            # MFn.raw_input(1,'\nShutdonw function\nPress Any key ')
        
        iMain = MFn.getMainMenu()


        # ก่อน shutdown ให้ถาม password
    print("Enter your password🤔")
    PWD = '12345'
    getPWD = MFn.getPWD(5,"*")
    while PWD != getPWD:
        getPWD = MFn.getPWD(5,"*")

    # ถ้าใส่ถูกแล้วถึงจะปิดได้
    MFn.raw_input(1,'\nShutdown \nByeee! \n...(please Press Any key)...')

