# -*- coding: utf-8 -*-
"""
Created on Sun Sep 14 22:12:40 2025

@author: FDT-CDTI
"""
import FileAndMem_class as FMC
import MenuFn as MFn

class Mainten:
    def __init__(self):
        self.gMem = FMC.goodsToMem()
        self.wlMem = FMC.walletToMem()
    
    def inputAllGoodsMemQty(self):
        """ Enter All Goods Qty """
        i = 0
        for oldOneMem in self.gMem:
            newQty = input(f'{oldOneMem.code}    {oldOneMem.name}    {oldOneMem.unitp}    Old Qty = {oldOneMem.qty} \nNew Qty is ')
            if (newQty == ''):
                newQty = oldOneMem.qty
            else:
                newQty = int(newQty)
                
            self.gMem[i].qty = newQty
            i += 1
            MFn.clearScreen()

        return self.gMem
    
    def inputAllWalletMemQty(self):
        """ Enter All walletMem Qty """
        i = 0
        for oldOneMem in self.wlMem:
            newQty = input(f'{oldOneMem.ID}    {oldOneMem.name}    {oldOneMem.value}    Old Qty = {oldOneMem.qty} \nNew Qty = ')
            if (newQty == ''):
                newQty = oldOneMem.qty
            else:
                newQty = int(newQty)
                
            self.wlMem[i].qty = newQty
            i += 1
            MFn.clearScreen()

        return self.wlMem
    
    def Up_Goods(self):
        fout = open('Goods.txt', 'w')
        x = ""
        for i in self.gMem:
            x += str(i) + "\n"
        fout.write(x)
        return 
    
    def Up_Wallet(self):
        fout = open('Wallet.txt', 'w')
        x = ""
        for i in self.wlMem:
            x += str(i) + "\n"
        fout.write(x)
        return 
    
    
if __name__ == '__Main__':
    x = Mainten()
    x.inputAllGoodsMemQty()
    
    
    
    
    