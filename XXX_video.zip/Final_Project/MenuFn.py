# -*- coding: utf-8 -*-
"""
Created on Tue Aug 29 14:36:26 2023

@author: kmutnb
"""
import FileAndMem_class as FMC

import os
import msvcrt

def clearScreen ():
    """ clear window screen """
    try:
        os.system('cls')  # Windows clear
        os.system('title Final Project — Modern UI')
    except Exception:
        pass
    try:
        from ui_theme import banner, sub
        print(banner("RETRO VENDING MACHINE 70s"))
        print(sub("credit='GO-07'"))
    except Exception:
        # If import fails, still return
        pass
    return

def raw_input (imax=1,prompt='\npress any key '):
    """ raw input """
    print(f'{prompt}',end='')

    sp  = bytes(' ',   'utf-8')
    mvl = bytes(chr(8),'utf-8')
    p   = bytes('*',   'utf-8')

    sstr = ''
    iloop = True
    i = 0
    while (iloop):
        c = msvcrt.getch()
        if ord(c) == 8:
            i -= 1
            msvcrt.putch(mvl)
            msvcrt.putch(sp)
            msvcrt.putch(mvl)
            sstr = sstr[0:-1]
        elif ord(c) == 13:
            iloop = False
        else:
            msvcrt.putch(c)
            sstr += chr(ord(c))
            i += 1

        if i >= imax:
            iloop = False
    return sstr

def raw_input (imax=1,prompt='\npress any key '):
    sbuff = input(prompt)
    if len (sbuff) <= imax:
        sstr = sbuff
    else:
        sstr = sbuff[:imax]
    return sstr
        
def getPWD (imax=20,csh='X'):
    """ get password """
    cpwd = bytes(csh,  'utf-8')

    sp  = bytes(' ',   'utf-8')
    mvl = bytes(chr(8),'utf-8')
    p   = bytes('*',   'utf-8')

    sstr = ''
    iloop = True
    i = 0
    while (iloop):
        c = msvcrt.getch()
        if ord(c) == 8:
            i -= 1
            msvcrt.putch(mvl)
            msvcrt.putch(sp)
            msvcrt.putch(mvl)
            sstr = sstr[0:-1]
        elif ord(c) == 13:
            iloop = False
        else:
            msvcrt.putch(cpwd)
            sstr += chr(ord(c))
            i += 1

        if i >= imax:
            iloop = False
    return sstr

def getMainMenu():
    """ get Main Menu """

    clearScreen()
    print('  [b] Buy 🛒')
    print('  [m] Maintenance 🔧')
    print('  [s] Shutdown ⏻')
    
    chList = ['b','m','s']
    ch = raw_input (1,'\nSelect <b, m, s> = ')
    while (ch not in chList):
        ch = raw_input (1,'\nPlease Select <b, m, s> = ')
    return ch
    
def getBuyGoodsMenu(gMem):  #จุดที่แก้จุดที่แก้จุดที่แก้
    """ get Buy Goods Menu """
    clearScreen()
    print(f'﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊')
    print(f"    🍫 Goods          Price  Q'ty      ")
    print(f'﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊﹊')
    chList = ['e']
    for i in range(1,10):
        if gMem[i].qty > 0:
            print(f'{gMem[i].code:3} {gMem[i].name:24} {gMem[i].unitp:4} {gMem[i].qty:4}   <{i}>')
            chList.append(str(i))
        else:
            print (f'{gMem[i].code:3} {gMem[i].name:24} {gMem[i].unitp:4} {" ":4}')
        
    print(f'.・゜゜・　　・゜゜・．.・゜゜・　　・゜゜・．.・゜゜・　　')    
    print(f'End select    <e>')

    ch = raw_input (1,'\nSelect = ')
    while (ch not in chList):
        ch = raw_input (1,'\nPlease Select = ')
        
    return ch

def showAllValueMoney(mMem):
    """ return all Value of Moneyset"""
    totalMoney = 0
    mMemSize = len(mMem)
    for i in range (mMemSize):
        totalMoney += mMem[i].showTotalValue()
        
    return totalMoney

def getCashIn(gBuy,mMem):
    """ get Cash In """
    clearScreen ()
    totalValueMoney = showAllValueMoney(mMem)
    balanceValue = gBuy.unitp - totalValueMoney
    print(f'Buy Goods [{gBuy.name}] price = {gBuy.unitp:4}')
    print(f'Cash In = {totalValueMoney:4}  remaind = {balanceValue:4}')
    print(f'💸💸💸💸💸💸💸💸💸💸💸💸💸💸💸💸')
    print(f"    Buy 🛒          Value  Q'ty     ")
    print(f'💸💸💸💸💸💸💸💸💸💸💸💸💸💸💸💸')
    
    chList = ['c']
    for i in range(1,10):
        if mMem[i].qty >= 0:
            print (f'{mMem[i].ID:3} {mMem[i].name:20} {mMem[i].value:4} {mMem[i].qty:4}   <{i}>')
            chList.append(f'{i}')
        else:
            print (f'{mMem[i].ID:3} {mMem[i].name:20} {mMem[i].unitp:4} {" ":4}')
        
    print(f'♡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━♡')    
    print(f'Cancel select    <c>')

    chList = ['1','2','3','4','5','6','7','8','9','c']
    ch = raw_input (1,'\nSelect = ')
    while (ch not in chList):
        ch = raw_input (1,'\nPlease Select = ')
    return ch

def getCashInMenu(gBuy):
    """ get Cash In Menu """
    cashMem = FMC.walletToInitCashMem()      # create cashMem same as wMem

    ch = getCashIn(gBuy,cashMem)
    if ch != 'c':
        cashMem[int(ch)].qty += 1
    totalMoney = showAllValueMoney(cashMem)
    
    while (ch != 'c') and (totalMoney < gBuy.unitp):
        ch = getCashIn(gBuy,cashMem)
        if ch != 'c':
            cashMem[int(ch)].qty += 1           
            totalMoney = showAllValueMoney(cashMem)

    return ch,cashMem

# if __name__ == '__main__': 
    
    
    
    
    
    
    
    
    # gMem = FMC.goodsToMem()
    # gBuy = FMC.buyGoodsItem(9,gMem)
                   
    # ch, cashIn = getCashInMenu(gBuy)
    
    # totalMoney = showAllValueMoney(cashIn)
    # print(f'\n\nChoose is [{ch}]')
    # print(f'TotalMoney is {totalMoney}')

    # ans = raw_input (imax=1,prompt='\npress any key ')
    # print('\n')
    # print(ans)
    # r = input('\nPress Enter')