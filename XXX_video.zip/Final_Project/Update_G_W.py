# # -*- coding: utf-8 -*-
# """
# Created on Sat Sep 13 10:37:51 2025

# @author: FDT-CDTI
# """
import Change_Money as CT
import FileAndMem_class as FT
import MenuFn as MFn


def LodSinkar(self, choice):
    # ... วนหา item ที่ code == choice ...
    for item in self.pathen:
        if str(item.code) == str(choice):
            if item.qty <= 0:
                MFn.raw_input(1, '\nOut of stock!\nPress Any key ')
                return  # ไม่อัปเดตไฟล์ ถ้าของหมด
            # มีของอยู่ จึงตัดสต๊อก
            item.qty -= 1
            break
    # จากนั้นค่อยเขียนกลับไฟล์ตามเดิม (Up_Goods)


class Update:
    def __init__(self,pathen):
        self.pathen = pathen
        
    def LodSinkar(self,choice):
        for i in self.pathen:
            if i.code == choice:
                i.qty -= 1
        return self.pathen
    
    def Up_Goods(self):
        fout = open('Goods.txt', 'w')
        x = ""
        for i in self.pathen:
            x += str(i) + "\n"
        fout.write(x)
        return 
    
    def PurmTung(self,choice):
        for i, Value in enumerate(self.pathen):
            if choice[i].qty != 0:
                Value.qty += choice[i].qty
        return self.pathen
    
    def LodTung(self,choice):
        for i, Value in enumerate(self.pathen):
            if choice[i-1] != 0:
                if Value.qty != 0:
                    Value.qty -= choice[i-1]
        return self.pathen
    
    def Up_Wallet(self):
        fout = open('Wallet.txt', 'w')
        x = ""
        for i in self.pathen:
            x += str(i) + "\n"
        fout.write(x)
        return 
                
if __name__ == '__main__':
    
    Up_G = Update(FT.goodsToMem())
    Up_G.LodSinkar('1')
    Up_G.Up_Goods()
    input('')
            
            
            
            