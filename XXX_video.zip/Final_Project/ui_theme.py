
# ui_theme.py - lightweight console "modern" theme (ANSI, no deps)
# Safe to import on Windows 10+ (ANSI supported in default terminal).
# Provides simple helpers for headings and muted text.

RESET = "\x1b[0m"
DIM = "\x1b[2m"
BOLD = "\x1b[1m"
FG = {
    "primary": "\x1b[38;2;37;99;235m",   # blue
    "accent":  "\x1b[38;2;105;195;255m", # cyan
    "muted":   "\x1b[38;2;140;140;160m", # gray
    "text":    "\x1b[38;2;220;220;230m"  # near-white
}
BG = {
    "panel":   "\x1b[48;2;20;22;28m",
    "canvas":  "\x1b[48;2;12;14;18m"
}

def line(width=60, char="─"):
    return FG["muted"] + char * width + RESET

def heading(title: str, width=60):
    title = f"  {title.strip()}  "
    side = "─"
    pad = max(0, width - len(title))
    left = pad // 2
    right = pad - left
    return (
        FG["primary"]
        + "┌" + side * left
        + "┤"
        + BOLD + FG["accent"] + title + RESET + FG["primary"]
        + "├" + side * right
        + "┐"
        + RESET
    )

def sub(text: str):
    return DIM + FG["muted"] + text + RESET

def banner(app_name="Final Project", width=60):
    top = FG["primary"] + "╔" + "═" * (width-2) + "╗" + RESET
    bot = FG["primary"] + "╚" + "═" * (width-2) + "╝" + RESET
    name = (BOLD + FG["accent"] + f" {app_name} " + RESET)
    mid = FG["primary"] + "║" + RESET
    pad = max(0, width - 2 - len(app_name) - 2)
    left = " " * (pad // 2)
    right = " " * (pad - len(left))
    center = left + name + right
    return "\n".join([top, mid + center + mid, bot])
